package com.example.demo.service;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Admin;
import com.example.demo.repository.AdminRepo;



@Service
public class AdminService
{
	@Autowired
	AdminRepo usr;
	
		
	public boolean checkuser(Admin u)
	{
		Admin us = usr.findAll().stream()
		.filter(m->m.getUsername().toLowerCase().equals(u.getUsername().toLowerCase()))
		.collect(Collectors.toList()).get(0);
		
		if(us!=null)
			return true;
		else
			return false;		
	}
}

