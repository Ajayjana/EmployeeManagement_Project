import{ Injectable } from'@angular/core';
import{ HttpClient } from'@angular/common/http';
import{ Observable } from'rxjs';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { Admin } from './admin';

@Injectable({
  providedIn: 'root'
})
export class CustomService {

  //DI for HttpClient modules services
  constructor(private http:HttpClient) { }

  userexists(data:Admin)
  {
    return this.http.post("http://localhost:4200/user/checkuser",data)
  }

  private getEmployees(){
    return this.http.get<EmployeeListComponent[]>("http://localhost:4200//employees ")
  }


}


